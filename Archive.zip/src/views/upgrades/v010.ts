import { MarkData } from '@/views/DataModel'

export interface ExportMarkDataV010 {
    markData: MarkData[]
    version: string
}
