module.exports = {
  devServer: {
    overlay: {
      warning: true,
      errors: true
    }
  }
}
